import React from "react";
import AllRoutes from "views/AllRoutes";

const App = () => {
  return (
    <div>
      <AllRoutes />
    </div>
  );
};

export default App;
