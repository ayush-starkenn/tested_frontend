const OngoingTrips = () => {
  return (
    <div>
      <h1>ongoing trips</h1>
    </div>
  );
};

export default OngoingTrips;
